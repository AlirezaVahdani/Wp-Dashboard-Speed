<?php defined('ABSPATH') || die;
/**
 * WP-Dashboard-Speedup
 *
 * @author            Alireza Vahdani
 * @copyright         Alireza Vahdani
 * @license           Alireza Vahdani
 *
 * @wordpress-plugin
 *
 * Plugin Name:         افزایش سرعت پیشخوان وردپرس
 * Plugin URI:          https://www.cafetadvin.com/
 * Description:         این افزونه با بالابردن سرعت پیشخوان وردپرس تجربه خوبی از کار با وردپرس را به شما هدیه می دهد
 * Version:             1.0.2
 * Requires at least:   5.0
 * Requires PHP:        7.4
 * Author:              علیرضا وحدانی
 * Author URI:          https://github.com/alirezavahdani
 * License:             Buy Me a Coffee :)
 */


add_action( 'init', 'remove_dns_prefetch' );
function  remove_dns_prefetch () {
	remove_action( 'wp_head', 'wp_resource_hints', 2, 99 );
}

/**
 * Disable the emoji's
 */
function disable_emojis() {
 remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
 remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
 remove_action( 'wp_print_styles', 'print_emoji_styles' );
 remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
 remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
 remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
 remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
 add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
 add_filter( 'wp_resource_hints', 'disable_emojis_remove_dns_prefetch', 10, 2 );
}
add_action( 'init', 'disable_emojis' );
 
/**
 * Filter function used to remove the tinymce emoji plugin.
 * 
 * @param array $plugins 
 * @return array Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
 if ( is_array( $plugins ) ) {
 return array_diff( $plugins, array( 'wpemoji' ) );
 } else {
 return array();
 }
}
 
/**
 * Remove emoji CDN hostname from DNS prefetching hints.
 *
 * @param array $urls URLs to print for resource hints.
 * @param string $relation_type The relation type the URLs are printed for.
 * @return array Difference betwen the two arrays.
 */
function disable_emojis_remove_dns_prefetch( $urls, $relation_type ) {
 if ( 'dns-prefetch' == $relation_type ) {
 /** This filter is documented in wp-includes/formatting.php */
 $emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/' );
 
$urls = array_diff( $urls, array( $emoji_svg_url ) );
 }
 
return $urls;
}


/** Block External requests **/

function TextHasString($text, $string) {
	return strpos($text, $string) !== false;
}


function BlockExternalHostRequests ($false, $parsed_args, $url) {
	$blockedHosts = [
		'elementor.com',
		'github.com',
		'yoast.com',
		'yoa.st',
		'api.wordpress.org',
		'w.org',
		'unyson.io',
		'siteorigin.com',
		'woocommerce.com',
		'rankmath.com',
		'googleapis.com',
		'fonts.googleapis.com',
		'cdnjs.cloudflare.com',
		'cloudflare.com',
	];

	foreach ( $blockedHosts as $host ) {
		if ( !empty($host) && TextHasString($url, $host) ) {
			return [
				'headers'  => '',
				'body'     => '',
				'response' => '',
				'cookies'  => '',
				'filename' => ''
			];
		}
	}

	return $false;
}

add_filter('pre_http_request', 'BlockExternalHostRequests', 10, 3);

// Remove WooCommerce Marketing Hub & Analytics Menu from the sidebar - for WooCommerce v4.3+
add_filter( 'woocommerce_admin_features', function( $features ) {
	return array_values(
		array_filter( $features, function($feature) {
			return ! in_array( $feature, [ 'marketing', 'analytics', 'analytics-dashboard', 'analytics-dashboard/customizable' ] );
		} ) 
	);
} );

/* Disable extensions menu WooCommerce */
add_action( 'admin_menu', 'wcbloat_remove_admin_addon_submenu', 999 );
function wcbloat_remove_admin_addon_submenu() {
remove_submenu_page( 'woocommerce', 'wc-addons');
}

/* Disable WooCommerce dashboard status widget */
add_action('wp_dashboard_setup', 'wcbloat_disable_woocommerce_status');
function wcbloat_disable_woocommerce_status() {
remove_meta_box('woocommerce_dashboard_status', 'dashboard', 'normal');
}

add_filter( 'woocommerce_marketing_menu_items', '__return_empty_array' );
	add_filter( 'woocommerce_admin_features', 'disable_features' );
function disable_features( $features ) {
	$marketing = array_search('marketing', $features);
	unset( $features[$marketing] );
	return $features;
}

add_filter( 'woocommerce_allow_marketplace_suggestions', '__return_false', 999 ); //Extension suggestions
add_filter( 'woocommerce_helper_suppress_admin_notices', '__return_true' ); //Connect to woocommerce.com

/* Disable Optional Tags */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'start_post_rel_link' );
remove_action( 'wp_head', 'index_rel_link' );
remove_action( 'wp_head', 'adjacent_posts_rel_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );

/* Disable Auto Update Theme */
add_filter( 'auto_update_theme', '__return_false' );

/* Disable Auto Update Plugin */
add_filter( 'auto_update_plugin', '__return_false' );